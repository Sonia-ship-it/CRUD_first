<?php
include 'connection.php';
if(isset($_POST['Submit'])) {
    $names = $_POST['name'];
    $emails = $_POST['email'];
    $pass = $_POST['email'];
    $pass = md5($pass);
    $sql = "INSERT INTO info_pass (name, email, created_at) VALUES ('$names', '$emails', NOW())";
    $result = $conn->query($sql);
    if($result) {
        $sql3 = "SET @counter := 0";
        $set = $conn -> query($sql3);
        $sql4 = "UPDATE info_pass SET id = @counter := (@counter+1)";
        $reset = $conn -> query($sql4);
    }
}
$sql1 = "SELECT * FROM info_pass";
$result1 = $conn -> query($sql1);
$num = mysqli_num_rows($result1);
$rows = mysqli_fetch_assoc($result1);
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    if(!empty($id)) {
        $sql2 = "DELETE FROM info_pass WHERE id = $id";
        $delete = $conn -> query($sql2);
    }
    else {
        echo "Id is empty";
    }
    if($delete) {
        $sql3 = "SET @counter := 0";
        $set = $conn -> query($sql3);
        $sql4 = "UPDATE info_pass SET id = @counter := (@counter+1)";
        $reset = $conn -> query($sql4);
        header("location: create.php");
        die();
    }
    else {
        die("failed to delete ".mysqli_error($conn));
    }
}
?>
<html>
<head>
<title>Tour</title>
    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }
        body {
            background: url('Unveiling 15 Aesthetic Mountain House Designs for Cozy Living.jpg') no-repeat;
            background-size: cover;
        }
        h3 {
            color:rgb(66, 99, 15);
            font-family: "Quicksand", sans-serif;
            font-size: 36px;
            margin-left:200px;
            margin-top: 70px;
        }
        thead {
            color: white;
            font-family: 'verdana', sans-serif;
        }
        table {
           margin-left: 245px;
           border-color: white;
           color:rgb(250, 252, 252);
           font-family: 'Roboto', sans-serif;
           transform: scale(1.1);
        }
        td {
            padding-left:8px;
            padding-bottom: 10px;
            padding-top: 10px;
            border: 1px solid white;
        }
        .edit {
            text-decoration: none;
            color: white;
            padding-right: 15px;
            padding: 5px;
            padding-left: 40px;
            margin-right: 10px;
            padding-right: 40px;
            border-radius: 7px;
            background-color: rgb(193, 116, 21);
        }
.del {
    text-decoration: none;
            color: white;
            padding-right: 15px;
            padding: 5px;
            padding-left: 30px;
            margin-right: 10px;
            padding-right: 30px;
            border-radius: 7px;
            background-color: rgb(193, 116, 21);
}
    </style>
</head>
<body>
    <section>
<h3>People whom you are in the same trip</h3><br><br><br>
<table border="1" cellspacing="0" width="60%" >
    <thead>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Created_at</th>
        <th>Actions</th>
    </thead>
    <tbody>
        <?php
        if($num>0){
            while($rows)  {
        echo
     "<tr>
        <td style='padding-left: 15px; padding-right: 17px; '>{$rows['id']}</td>
        <td>{$rows['name']}</td>
        <td>{$rows['email']}</td>
        <td>{$rows['created_at']}</td>
        <td><a href='update.php?id={$rows['id']}' class='edit'>Edit</a><a href='create.php?id={$rows['id']}' class='del'>Delete</a></td>
    </tr>";
    $rows = mysqli_fetch_assoc($result1);
} 
}
    ?>
    </tbody>
</table></section>
</body>
</html>