<?php
include 'connection.php';
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql6 = "SELECT * FROM info_pass WHERE id = $id";
    $data = $conn -> query($sql6);
    if(mysqli_num_rows($data) > 0) {
        $row = mysqli_fetch_assoc($data);
    }
    else {
        echo "Not found";
    }
}
if(isset($_POST['update'])) {
    $up_id = $_POST['id'];
   $up_name = $_POST['name'];
   $up_email = $_POST['email'];
   $sql5 = "UPDATE info_pass SET name = '$up_name', email = '$up_email', created_at = NOW() WHERE id = $up_id";
   $updating = $conn -> query($sql5);
   if($updating) {
    header("location: create.php");
    die();
   }
   else {
    die("Updating failed ". mysqli_error($conn));
   }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tour</title>
    <link rel="stylesheet" href="sando.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <style>
        input[type="submit"]{
    background-color: green;
    color: white;
    border: none;
    border-radius: 13px;
    padding: 5px;
    padding-left: 75px;
    padding-right: 75px;
    padding-top: 8px;
    padding-bottom: 8px;
    /* padding-left: 5px;
    padding-right: 40px;
    padding-top: 8px;
    padding-bottom: 8px; */
}
#forest {
    height: 475px;
    width: 490px;
    float: right;
    padding-top: 10px;
    border-radius: 30px;
    padding-bottom: 9px;
    padding-right: 10px;
    top:0;    
}
        </style>
</head>
<body>
    <div class="content">
     <section>
    <img src="Forest.jpg" id="forest">
    <div class="box">
<h3><b>voyger</b></h3><br>
<h2>Start your <br> perfect trip</h2><br>
<div class="elements">
<i class="fa-brands fa-apple" id="apple"></i>
<img src="google.jpg" id="google"><i class="fa-brands fa-facebook" id="fb"></i></div><br><br>
<p style="color:black ;font-family: Arial; font-size: 12px; padding-left: 75px;">or</p><br><br>
<form action="" method="post">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>" >
<input type="text" name="name" value="<?php echo $row['name']; ?>"  placeholder="Full name"><br><br>
<input type="email" name="email" value="<?php echo $row['email']; ?>" placeholder="Email"><br><br>
<input type="submit" name="update" value="Update">
<p>Already have an account? <a href=""><b>Log in</b></a></p>
</div>
</section>
</div></form>
</body>
</html>