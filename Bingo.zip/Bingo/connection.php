<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "passengers";
$conn = new mysqli($servername, $username, $password, $dbname);
// if(!$conn) {
//     die ("Failed to connect ". mysqli_connect_error());
// }
// else {
//     echo "Connection made successful!";
// }
?>